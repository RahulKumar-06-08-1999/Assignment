const asyncHandler = require('../middleware/async');
const User = require('../models/User');


// @desc      Get all users
// @route     GET /api/v1/auth/users
// @access    Private/Admin
exports.getUsers = asyncHandler(async (req, res, next) => {
  res.status(200).json(res.advancedResults);
});



// @desc      Get single user
// @route     GET /api/v1/auth/users/:id
// @access    Private/Admin
exports.getUser = asyncHandler(async (req, res, next) => {
  const user = await User.findById(req.params.id);

  res.status(200).json({
    success: true,
    data: user
  });
});



// @desc      Create user
// @route     POST /api/v1/auth/users
// @access    Private/Admin
exports.createUser = asyncHandler(async (req, res, next) => {
  const user = await User.create(req.body);

  res.status(201).json({
    success: true,
    data: user
  });
});



// @desc      Update user
// @route     PUT /api/v1/auth/users/:id
// @access    Private/Admin
exports.updateUser = asyncHandler(async (req, res, next) => {
  const user = await User.findByIdAndUpdate(req.params.id, req.body, {
    new: true,
    runValidators: true
  });

  res.status(200).json({
    success: true,
    data: user
  });
});



// @desc      Delete user
// @route     DELETE /api/v1/auth/users/:id
// @access    Private/Admin
exports.deleteUser = asyncHandler(async (req, res, next) => {
  await User.findByIdAndDelete(req.params.id);

  res.status(200).json({
    success: true,
    data: {}
  });
});





exports.aggregateUserData = async () => {
  try {
      const aggregationResult = await User.aggregate([
            // Group by country to count users in each country
    // Group by country to count users in each country
    {
      $group: {
        _id: "$country", // Group by country
        totalUsers: { $sum: 1 }, // Count total number of users in each country
        totalAge: { $sum: "$age" } // Calculate total age in each country
      }
    },
    // Project to calculate average age in each country
    {
      $project: {
        _id: 0, // Exclude _id field
        country: "$_id", // Rename _id as country
        totalUsers: 1,
        averageAge: { $divide: ["$totalAge", "$totalUsers"] } // Calculate average age in each country
      }
    },
    // Group again to calculate the count of users in each country and overall average age
    {
      $group: {
        _id: null, // Group by null to compute aggregate values across all documents
        countries: {
          $push: {
            country: "$country", // Store the country name
            totalUsers: "$totalUsers", // Store the count of users in each country
            averageAge: { $round: ["$averageAge", 2] } // Round average age to 2 decimal places
          }
        },
        overallAverageAge: { $avg: "$averageAge" } // Calculate overall average age
      }
    },
    // Project to rename the fields for clarity
    {
      $project: {
        _id: 0,
        countries: 1,
        overallAverageAge: { $round: ["$overallAverageAge", 2] } // Round overall average age to 2 decimal places
      }
    }
      ]);

      return aggregationResult;
      
  } catch (error) {
      console.error('Error aggregating user data:', error);
      throw error; // Propagate the error to the caller
  }
};
