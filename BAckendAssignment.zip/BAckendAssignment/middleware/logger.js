// Middleware function to log request details to the console
// @desc Log request to console
const logger = async (req, res, next) => {
    // Get the current timestamp
    const timestamp = new Date().toISOString();
  
    // Extract access token from headers
    // const accessToken = req.headers.authorization || 'N/A';

    // Extract access token from cookies
    const accessToken = req.cookies.token || 'N/A';
  
    // Log the request method, URL, access token, and timestamp
    console.log(`[${timestamp}] ${req.method}: ${req.originalUrl}, AccessToken: "${accessToken}"`);
  
    // Log the request method, protocol, host, and original URL
    console.log(`${req.method} ${req.protocol}://${req.get('host')} ${req.originalUrl}`);
    
    // Proceed to the next middleware
    next();
};

// Export the logger middleware function
module.exports = logger;
