const express = require("express");
const router = express.Router();

const User = require("../models/User");

const { protect, authorize } = require("../middleware/auth");
const advanceResults = require("../middleware/advanceResults");

const {   
    getUsers,
    getUser,
    createUser,
    updateUser,
    deleteUser,
    aggregateUserData
} = require("../controller/user");

router.use(protect);

router.get("/aggregateUserData", advanceResults(User), async (req, res, next) => {
    try {
        // Aggregate user data
        const aggregatedData = await aggregateUserData();

        let totalUsers = 0;
        let count = 0;

        if (Array.isArray(aggregatedData) && aggregatedData.length > 0) {
            // Calculate the count based on the number of countries
            count = aggregatedData[0].countries.length;

            // Calculate total number of users
            aggregatedData[0].countries.forEach(country => {
                totalUsers += country.totalUsers;
            });
        }

        res.status(200).json({
            success: true,
            count: count,
            totalUsers: totalUsers,
            data: aggregatedData,
        });
    } catch (error) {
        next(error);
    }
});



router.route("/").get(advanceResults(User), getUsers).post(createUser);
router.route("/:id").get(getUser).put(updateUser).delete(deleteUser);

module.exports = router;
