import * as React from 'react';
import './home.css';
import logo from "../../images/Logo.png";
import Box from '@mui/material/Box';
import Paper from '@mui/material/Paper';
import Stack from '@mui/material/Stack';
import { styled } from '@mui/material/styles';
import mainstep from "../../images/MainStep.png";
import Typography from "@mui/material/Typography";
import classicFilter from "../../images/classFilter.png";
import Image1 from "../../images/image1.png";
import Frame1 from "../../images/Frame1.png";
import Frame2 from "../../images/Frame2.png";
import Frame3 from "../../images/Frame3.png";
import indicate from "../../images/inicate.png";
import Button from '@mui/material/Button';
import { Link } from "react-router-dom";


import airport1 from "../../images/airport1.png";
import airport2 from "../../images/airport2.png";
import highway from "../../images/highway.png";
import map from "../../images/map.png";

import Step1 from './step1';

const Item = styled(Paper)(({ theme }) => ({
  backgroundColor: theme.palette.mode === 'dark' ? '#1A2027' : '#fff',
  ...theme.typography.body2,
  padding: theme.spacing(1),
  textAlign: 'center',
  color: theme.palette.text.secondary,
}));

function LandPage() {

  const handleViewMoreClick = () => {
    window.scrollTo(0, 0); // Scroll to the top of the page
  };

  return (
    <div className='landpage'>

    <div className="lcontainer">
      <div className="box1">
        <img src={logo} alt="Logo" style={{marginTop:"75px", marginLeft:"120px"}} />
      </div>
      <div className="box2" style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', color: "grey" }}>
        Cart
      </div>
      <div className="box3" style={{ display: 'flex', justifyContent: 'center', alignItems: 'center'}}>
        Market
      </div>
      <div className="box4" style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', color: "grey" }}>
        Setting
      </div>
      <div className="box5" style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', color: "grey" }}>
        logout
      </div>
      <div className="box6"></div>
    </div>


    <div className='rcotainer'>
    <Box sx={{ width: '1115px', height: "1026px" }}>
      <Stack spacing={5}>

      <Item style={{ marginLeft: "323px", marginTop: "-1019px", width: "1115px", height: "107px"}}>
        <div style={{marginLeft:"-775px", marginTop:"25px"}}>
          <Button variant="contained" style={{ width: "166px", height: "52px", color:"#4375FB" }}>
            <Typography variant="body1" style={{
            fontFamily: 'Switzer',
            fontSize: '14px',
            fontWeight: 400,
            lineHeight: '18px',
            letterSpacing: '0em',
            textAlign: 'left',
            color: "#F2F2F2",
            width: '104px',
            height: '18px',
            whiteSpace: 'nowrap',
            marginLeft: '-28px',
          }}>
          <Link to='/signup' style={{ textDecoration: 'none', color: 'inherit' }} >
          Complete Profile
          </Link>
          {/* Complete Profile */}
          </Typography>
          </Button>
        </div>


        <div style={{marginLeft:"845px"}}>
           <div style={{
              width: "22.5px",
              height: "5.17px",
              position: "absolute",
              top: "16.75px",
              color: "#191819",
              marginTop: "30px"
            }}>
              <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="#191819" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" class="feather feather-bell">
              <path d="M18 8a6 6 0 0 0-12 0v5a2 2 0 0 0-2 2h16a2 2 0 0 0-2-2z"></path>
              <path d="M13.73 21a2 2 0 0 1-3.46 0"></path>
              </svg>
            </div>
          {/* <img src={iconinteraction} alt="IconInteraction" style={{ width: "23px", height: "22px" }} /> */}
        </div>
      </Item>


        <Item style={{ marginLeft:"323px", marginTop:"2px", width: "1115px", height:"102px"}}>
        <Typography variant="body1" style={{
          fontFamily: 'Switzer',
          fontSize: '32px',
          fontWeight: 700,
          lineHeight: '42px',
          letterSpacing: '-0.02em',
          textAlign: 'left',
          color: "#000000",
          marginLeft: "68px",
          marginTop: "25px"
        }}>
          Choose your new site
        </Typography>

          <div style={{marginLeft:"400px", marginTop:"-32px"}}>
          <img src={mainstep} alt="Mainstep" style={{ width: "250px", height: "32px" }} />
          </div>
        </Item>


        <Item style={{ marginLeft:"323px", marginTop:"2px", width: "1115px", height:"807px", gap:"10px"}}>
          <div style={{ width: "995px", height: "51px", marginTop: "51px", marginLeft: "40px"}}>
            <img src={classicFilter} alt="ClassicFilter"/>
          </div>

          <div style={{ width: "995px", height: "371px" , marginTop: "10px", marginLeft: "40px"}}>
            <img src={Image1} alt="image1" />
          </div>

          <Box style={{ width: "995px", height: "315px", marginLeft: "40px", marginTop:"13px", border: "1px solid grey" }}>
            <div style={{width:"462px", height:"255px"}}>
            <Typography variant="body1" style={{
            fontFamily: 'Switzer',
            fontSize: '32px',
            fontWeight: 700,
            lineHeight: '42px',
            letterSpacing: '-0.02em',
            textAlign: 'left',
            marginLeft: "57px",
            marginTop: "25px",
            color: "#000000"
            }}>
              Theme Park Site
            </Typography>

            <div style={{marginTop: "21px"}}>
            <img src={Frame1} alt="location" />
            <img src={Frame2} alt="locationDescription" />
            </div>

            <div style={{marginTop:"38px", marginLeft:"-114px"}}>
              <img src={indicate} alt="locationindicate" />
            </div>
            
            <div style={{marginLeft:"57px", marginTop:"25px"}}>
             <img src={Frame3} alt="amountdetailing" />
            </div>

        <div style={{marginLeft:"650px", marginTop:"-255px"}}>
          <Button variant="contained" style={{ width: "273px", height: "52px", color:"#4375FB" }}>
            <Typography variant="body1" style={{
            fontFamily: 'Switzer',
            fontSize: '14px',
            fontWeight: 400,
            lineHeight: '18px',
            letterSpacing: '0em',
            textAlign: 'left',
            color: "#F2F2F2",
            width: '104px',
            height: '18px',
            whiteSpace: 'nowrap',
            marginLeft: '25px',
          }}
          onClick={handleViewMoreClick} // Scroll to the top before opening FAQ
          >
          <Link to='/step1' style={{ textDecoration: 'none', color: 'inherit' }} >  
          Complete
          </Link>
          </Typography>
          </Button>

          <Button variant="contained" style={{ width: "136px", height: "52px", backgroundColor:"#FFFFFF", border: "1px solid blue", gap:"10px", marginLeft:"137px", padding:"15px", marginTop:"5px"}}>
            <Typography variant="body1" style={{
            fontFamily: 'Switzer',
            fontSize: '14px',
            fontWeight: 400,
            lineHeight: '18px',
            letterSpacing: '0em',
            textAlign: 'left',
            color: "#4375FB",
            width: '136px',
            height: '52px',
            whiteSpace: 'nowrap',
            marginLeft: '12px',
            marginTop: "30px"
          }}>
          Site visit&nbsp;&nbsp;<span style={{ fontSize: '16px' }}>&gt;</span>
          </Typography>
          </Button>

          <Box style={{width:"273px", height:"37px", marginTop:"10px"}}>
          <Typography style={{
          fontFamily: 'Switzer',
          fontSize: '24px',
          fontWeight: 700,
          lineHeight: '32px',
          letterSpacing: '-0.02em',
          textAlign: 'left',
          width: "137px",
          height: "32px",
          color: "#4375FB"
          }}>
              Rs 20,00,000
          </Typography>

          <Box style={{width:"85px", height:"20px",  marginLeft:"195px", marginTop:"-14px"}}>
          <Typography style={{
            fontFamily: 'Switzer',
            fontSize: '15px',
            fontWeight: 400,
            lineHeight: '20px',
            letterSpacing: '-0.02em',
            textAlign: 'left',
            color: "#000000"
          }}>
              Rs 65.00,000
          </Typography>
          <div style={{
          width: '273px', // width: Fill (273px)
          height: '5px', // height: Hug (5px)
          display: 'flex',
          gap: '10px', // gap: 10px
          marginLeft: "-195px"
          }}>
            <div style={{ width: '125px', backgroundColor: '#4375FB' }}></div>
            <div style={{ width: '250px', backgroundColor: '#E2E2E2' }}></div>
          </div>

          </Box>

          </Box>

        </div>
          </div>
          </Box>
        </Item>

      </Stack>
    </Box>
    
    <Box>
    <Box style={{ marginLeft: "370px", marginTop: "-976px", width: "507px", height: "237px", border: "1px solid grey"}}>
        <div style={{width:"134px", height:"42px",}}>
          <Typography style={{
            fontFamily: 'Switzer',
            fontSize: '32px',
            fontWeight: 400,
            lineHeight: '42px',
            letterSpacing: '-0.02em',
            textAlign: 'left',
            color: "#000000",           
            marginLeft:"20px",
            marginTop:"20px"
          }}> 
            Overview
          </Typography>
          {/* <img src={Overview} alt="overview"  /> */}
        </div>

        <div style={{width:"447px", height:"105px",}}>
          <Typography style={{
            fontFamily: 'Switzer',
            fontSize: '16px',
            fontWeight: 400,
            lineHeight: '21px',
            letterSpacing: '-0.02em',
            textAlign: 'left',
            color: "#000000",           
            marginLeft:"20px",
            marginTop:"20px"
          }}> 
            Our AI feature simplifies your life by automating routine tasks. Spend more time on the things you love!Our AI feature simplifies your life by automating routine tasks. Spend more time on the things you love!Our AI feature simplifies your life by automating routine tasks. Spend more time on the things you love.
          </Typography>
          {/* <img src={Overview} alt="overview"  /> */}
        </div>
    </Box>

    <Box style={{marginLeft:"370px", width: "507px", height: "237px", border: "1px solid grey"}}>
        <div style={{width:"134px", height:"42px",}}>
          <Typography style={{
            fontFamily: 'Switzer',
            fontSize: '32px',
            fontWeight: 400,
            lineHeight: '42px',
            letterSpacing: '-0.02em',
            textAlign: 'left',
            color: "#000000",           
            marginLeft:"20px",
            marginTop:"20px"
          }}> 
            Why ?
          </Typography>
        </div>

        <div style={{width:"447px", height:"105px",}}>
          <Typography style={{
            fontFamily: 'Switzer',
            fontSize: '16px',
            fontWeight: 400,
            lineHeight: '21px',
            letterSpacing: '-0.02em',
            textAlign: 'left',
            color: "#000000",           
            marginLeft:"20px",
            marginTop:"20px"
          }}> 
          Our AI feature simplifies your life by automating routine tasks. Spend more time on the things you love!Our AI feature simplifies your life by automating routine tasks. Spend more time on the things you love!Our AI feature simplifies your life by automating routine tasks. Spend more time on the things you love.          </Typography>
          {/* <img src={Overview} alt="overview"  /> */}
        </div>
    </Box>
    
          
    <Box style={{marginLeft:"370px", width: "507px", height: "237px", border: "1px solid grey"}}>
        <div style={{width:"134px", height:"42px",}}>
          <Typography style={{
            fontFamily: 'Switzer',
            fontSize: '32px',
            fontWeight: 400,
            lineHeight: '42px',
            letterSpacing: '-0.02em',
            textAlign: 'left',
            color: "#000000",           
            marginLeft:"20px",
            marginTop:"20px"
          }}> 
            What ?
          </Typography>
        </div>

        <div style={{width:"447px", height:"105px",}}>
          <Typography style={{
            fontFamily: 'Switzer',
            fontSize: '16px',
            fontWeight: 400,
            lineHeight: '21px',
            letterSpacing: '-0.02em',
            textAlign: 'left',
            color: "#000000",           
            marginLeft:"20px",
            marginTop:"20px"
          }}> 
          Our AI feature simplifies your life by automating routine tasks. Spend more time on the things you love!Our AI feature simplifies your life by automating routine tasks. Spend more time on the things you love!Our AI feature simplifies your life by automating routine tasks. Spend more time on the things you love.          </Typography>

        </div>
    </Box>

    <Box style={{marginLeft:"370px", width: "507px", height: "237px", border: "1px solid grey"}}>
      <Box style={{width:"447px", height:"42px"}}>
      <Typography style={{
            fontFamily: 'Switzer',
            fontSize: '32px',
            fontWeight: 400,
            lineHeight: '42px',
            letterSpacing: '-0.02em',
            textAlign: 'left',
            color: "#000000",           
            marginLeft:"27px",
            marginTop:"20px"
          }}> 
            Landmarks
          </Typography>
      </Box>
      <Box style={{width:"447px", height:"193px"}}>
        <div style={{marginLeft:"27px"}}>
          <img src={airport1} alt="airportdistance"  />
          <img src={airport2} alt="terminaldistance"  />
          <img src={highway} alt="Highwaydistance"  />
        </div>
      </Box>
    </Box>

    <Box style={{marginLeft:"370px", width: "507px", height: "480px", border: "1px solid grey"}}>
        <div style={{width:"64px", height:"42px",}}>
          <Typography style={{
            fontFamily: 'Switzer',
            fontSize: '32px',
            fontWeight: 400,
            lineHeight: '42px',
            letterSpacing: '-0.02em',
            textAlign: 'left',
            color: "#000000",           
            marginLeft:"30px",
            marginTop:"20px"
          }}> 
            Map
          </Typography>
        </div>
        <div style={{width:"447px", height:"266px", padding:"30px", gap:"30px"}}>
          <img src={map} alt="mapimage"  />
        </div>
      </Box>       

      <Button variant="contained" style={{ width: "156px", height: "52px", backgroundColor:"#FFFFFF", border: "1px solid blue",  marginLeft:"697px", marginTop:"-135px"}}>
            <Typography variant="body1" style={{
            fontFamily: 'Switzer',
            fontSize: '14px',
            fontWeight: 400,
            lineHeight: '18px',
            letterSpacing: '0em',
            textAlign: 'left',
            color: "#4375FB",
            width: '96px',
            height: '18px',
            whiteSpace: 'nowrap',
            marginLeft: '-38px',
          }}>
          Schedule a call &nbsp;<span style={{ fontSize: '14px' }}>&gt;</span>
          </Typography>
          </Button> 
          <div style={{marginLeft:"880px", marginTop:"-1457px"}}>
          <Step1 />
          </div>
        
    </Box>
    </div>

   </div>
  );
}

export default LandPage;
