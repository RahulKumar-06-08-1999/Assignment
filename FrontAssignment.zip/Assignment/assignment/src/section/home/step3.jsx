import * as React from 'react';
import Box from '@mui/material/Box';
import Stack from '@mui/material/Stack';
import Paper from '@mui/material/Paper'; // Import Paper from MUI
import styled from '@mui/material/styles/styled'; // Import styled from MUI
import Typography from "@mui/material/Typography";
import Button from '@mui/material/Button';
import Checkbox from '@mui/material/Checkbox';
import { Link } from "react-router-dom";


const label = { inputProps: { 'aria-label': 'Checkbox demo' } };


const Item = styled(Paper)(({ theme }) => ({
  backgroundColor: theme.palette.mode === 'dark' ? '#1A2027' : '#fff',
  ...theme.typography.body2,
  padding: theme.spacing(1),
  textAlign: 'center',
  color: theme.palette.text.secondary,
}));

const Step3 = () => {

    const handleViewMoreClick = () => {
        window.scrollTo(0, 0); // Scroll to the top of the page
      };
      
  return (
    <div className='step1'>
      <Box sx={{ width: '458px', height: "961px"}}>

        <Stack spacing={0.1}>
          <Item style={{ width: "458px", height: "156px", padding: "20px", justify: "space-between",  border: "1px solid grey"}}>
          <div style={{ marginLeft:"-410px"}}>
          <Checkbox {...label} defaultChecked color="success" />
          </div>
          <Box>
          <Typography variant="body1" style={{
            fontFamily: 'Switzer',
            fontSize: '22px',
            // fontWeight: 600,
            lineHeight: '18px',
            letterSpacing: '0em',
            textAlign: 'left',
            color: "#000000",
            width: '104px',
            height: '18px',
            whiteSpace: 'nowrap',
            marginLeft: '64px',
            marginTop: "-25px"
          }}>
          Complete Profile
          </Typography>

          <Typography variant="body1" style={{
            fontFamily: 'Switzer',
            fontSize: '15px',
            lineHeight: '20px',
            letterSpacing: '-0.02em',
            textAlign: 'left',
            color: "#4375FB",
            width: '104px',
            height: '18px',
            whiteSpace: 'nowrap',
            marginLeft: "64px",
            padding: "3px"
          }}>
          Good job!
          </Typography>

          <Typography variant="body1" style={{
            fontFamily: 'Switzer',
            fontSize: '32px',
            fontWeight: 700,
            lineHeight: '42px',
            letterSpacing: '-0.02em',
            textAlign: 'left',
            color: "#4375FB",
            width: '143px',
            height: '42px',
            whiteSpace: 'nowrap',
            marginLeft: "64px",
            padding: "3px"
            }}>
          Complete
          </Typography>

          </Box>

           <div style={{marginLeft: "328px", marginTop:"-100px"}}> 
          <Typography variant="body1" style={{
            fontFamily: 'Switzer',
            fontSize: '20px',
            fontWeight: 400,
            lineHeight: '26px',
            letterSpacing: '-0.02em',
            textAlign: 'right',
            color: "#4375FB",
            width: '103px',
            height: '26px',
            whiteSpace: 'nowrap',
            // marginLeft: "284px",
            // marginBottom: "-200px",
            padding: "3px"
          }}>
          12/12/2023
          </Typography>
          </div>

          <div style={{marginLeft:"230px", marginTop:"75px"}}>
          <Button variant="contained" style={{ width: "149px", height: "52px", backgroundColor:"#FFFFFF", border: "1px solid blue", gap:"10px", marginLeft:"30px", padding:"15px", marginTop:"-10px"}}>
            <Typography variant="body1" style={{
            fontFamily: 'Switzer',
            fontSize: '14px',
            fontWeight: 400,
            lineHeight: '14px',
            letterSpacing: '0em',
            textAlign: 'left',
            color: "#4375FB",
            width: '65px',
            height: '18px',
            whiteSpace: 'nowrap',
            marginLeft: '-29px',
            marginTop: "1px"
          }}>
          Download &nbsp;&nbsp;<span style={{ fontSize: '16px' }}>▼</span>
          </Typography>
          </Button>
          </div>
          </Item>


          <Item style={{ width: "458px", height: "156px", padding: "20px", justify: "space-between",  border: "1px solid grey"}}>
          <div style={{ marginLeft:"-410px"}}>
          <Checkbox {...label} defaultChecked color="success" />
          </div>
          <Box>
          <Typography variant="body1" style={{
            fontFamily: 'Switzer',
            fontSize: '22px',
            // fontWeight: 600,
            lineHeight: '18px',
            letterSpacing: '0em',
            textAlign: 'left',
            color: "#000000",
            width: '104px',
            height: '18px',
            whiteSpace: 'nowrap',
            marginLeft: '64px',
            marginTop: "-25px"
          }}>
          Step 1
          </Typography>

          <Typography variant="body1" style={{
            fontFamily: 'Switzer',
            fontSize: '15px',
            lineHeight: '20px',
            letterSpacing: '-0.02em',
            textAlign: 'left',
            color: "#4375FB",
            width: '104px',
            height: '18px',
            whiteSpace: 'nowrap',
            marginLeft: "64px",
            padding: "3px"
          }}>
          5% of total amount
          </Typography>

          <Typography variant="body1" style={{
            fontFamily: 'Switzer',
            fontSize: '32px',
            fontWeight: 700,
            lineHeight: '42px',
            letterSpacing: '-0.02em',
            textAlign: 'left',
            color: "#4375FB",
            width: '143px',
            height: '42px',
            whiteSpace: 'nowrap',
            marginLeft: "64px",
            padding: "3px"
            }}>
          Rs 1,00,000
          </Typography>

          </Box>

           <div style={{marginLeft: "328px", marginTop:"-100px"}}> 
          <Typography variant="body1" style={{
            fontFamily: 'Switzer',
            fontSize: '20px',
            fontWeight: 400,
            lineHeight: '26px',
            letterSpacing: '-0.02em',
            textAlign: 'right',
            color: "#4375FB",
            width: '103px',
            height: '26px',
            whiteSpace: 'nowrap',
            // marginLeft: "284px",
            // marginBottom: "-200px",
            padding: "3px"
          }}>
          14/12/2023
          </Typography>
          </div>

          <div style={{marginLeft:"230px", marginTop:"75px"}}>
          <Button variant="contained" style={{ width: "149px", height: "52px", backgroundColor:"#FFFFFF", border: "1px solid blue", gap:"10px", marginLeft:"30px", padding:"15px", marginTop:"-10px"}}>
            <Typography variant="body1" style={{
            fontFamily: 'Switzer',
            fontSize: '14px',
            fontWeight: 400,
            lineHeight: '14px',
            letterSpacing: '0em',
            textAlign: 'left',
            color: "#4375FB",
            width: '65px',
            height: '18px',
            whiteSpace: 'nowrap',
            marginLeft: '-19px',
            marginTop: "1px"
          }}>
          Receipt &nbsp;&nbsp;<span style={{ fontSize: '16px' }}>▼</span>
          </Typography>
          </Button>
          </div>
          </Item>


          <Item style={{ width: "458px", height: "156px", padding: "20px", justify: "space-between",  border: "1px solid grey"}}>
          <div style={{ marginLeft:"-410px"}}>
          <Checkbox {...label} defaultChecked color="success" />
          </div>
          <Box>
          <Typography variant="body1" style={{
            fontFamily: 'Switzer',
            fontSize: '22px',
            // fontWeight: 600,
            lineHeight: '18px',
            letterSpacing: '0em',
            textAlign: 'left',
            color: "#000000",
            width: '104px',
            height: '18px',
            whiteSpace: 'nowrap',
            marginLeft: '64px',
            marginTop: "-25px"
          }}>
          Step 2
          </Typography>

          <Typography variant="body1" style={{
            fontFamily: 'Switzer',
            fontSize: '32px',
            fontWeight: 700,
            lineHeight: '42px',
            letterSpacing: '-0.02em',
            textAlign: 'left',
            color: "#4375FB",
            width: '143px',
            height: '42px',
            whiteSpace: 'nowrap',
            marginLeft: "60px",
            padding: "3px"
            }}>
          Complete
          </Typography>

          </Box>

           <div style={{marginLeft: "328px", marginTop:"-80px"}}> 
          <Typography variant="body1" style={{
            fontFamily: 'Switzer',
            fontSize: '20px',
            fontWeight: 400,
            lineHeight: '26px',
            letterSpacing: '-0.02em',
            textAlign: 'right',
            color: "#4375FB",
            width: '103px',
            height: '26px',
            whiteSpace: 'nowrap',
            // marginLeft: "284px",
            // marginBottom: "-200px",
            padding: "3px"
          }}>
          15/12/2023
          </Typography>
          </div>

          <div style={{marginLeft:"230px", marginTop:"75px"}}>
          <Button variant="contained" style={{ width: "149px", height: "52px", backgroundColor:"#FFFFFF", border: "1px solid blue", gap:"10px", marginLeft:"30px", padding:"15px", marginTop:"-10px"}}>
            <Typography variant="body1" style={{
            fontFamily: 'Switzer',
            fontSize: '14px',
            fontWeight: 400,
            lineHeight: '14px',
            letterSpacing: '0em',
            textAlign: 'left',
            color: "#4375FB",
            width: '65px',
            height: '18px',
            whiteSpace: 'nowrap',
            marginLeft: '-29px',
            marginTop: "1px"
          }}>
          Download &nbsp;&nbsp;<span style={{ fontSize: '16px' }}>▼</span>
          </Typography>
          </Button>
          </div>
          </Item>


          <Item style={{ width: "458px", height: "156px",  padding: "20px", justify: "space-between", border: "1px solid grey"}}>
          <div style={{ marginLeft:"-410px"}}>
          <Checkbox {...label} />
          {/* <img src={rectagle} alt="" /> */}
          </div>
          <Typography variant="body1" style={{
            fontFamily: 'Switzer',
            fontSize: '22px',
            fontWeight: 600,
            lineHeight: '18px',
            letterSpacing: '0em',
            textAlign: 'left',
            color: "#000000",
            width: '104px',
            height: '18px',
            whiteSpace: 'nowrap',
            marginLeft: '64px',
            marginTop: "-25px"
          }}>
          Step 3
          </Typography>

          <div style={{marginLeft:"230px", marginTop:"75px"}}>
          <Button variant="contained" style={{ width: "169px", height: "52px", color: "#808080",  cursor: "not-allowed" }} >
            <Typography variant="body1" style={{
              fontFamily: 'Switzer',
              fontSize: '14px',
              fontWeight: 400,
              lineHeight: '18px',
              letterSpacing: '0em',
              textAlign: 'left',
              color: "#FFFFFF",
              width: '104px',
              height: '18px',
              whiteSpace: 'nowrap',
              marginLeft: '25px',
            }}
            onClick={handleViewMoreClick} // Scroll to the top before opening FAQ
            >
            <Link to='/step4' style={{ textDecoration: 'none', color: 'inherit' }} >
            Complete
            </Link>
            </Typography>
          </Button>
          </div>
          </Item>


          <Item style={{ width: "458px", height: "156px",  padding: "20px", justify: "space-between", border: "1px solid grey"}}>
          <div style={{ marginLeft:"-410px"}}>
          <Checkbox {...label} /> 
          {/* <img src={rectagle} alt="" /> */}
          </div>
          <Typography variant="body1" style={{
            fontFamily: 'Switzer',
            fontSize: '22px',
            fontWeight: 600,
            lineHeight: '18px',
            letterSpacing: '0em',
            textAlign: 'left',
            color: "grey",
            width: '104px',
            height: '18px',
            whiteSpace: 'nowrap',
            marginLeft: '64px',
            marginTop: "-25px"
          }}>
          Step 4
          </Typography>

          <div style={{marginLeft:"230px", marginTop:"75px"}}>
          <Button variant="contained" style={{ width: "169px", height: "52px", color: "#808080", backgroundColor: "#CCCCCC", cursor: "not-allowed" }} disabled>
            <Typography variant="body1" style={{
              fontFamily: 'Switzer',
              fontSize: '14px',
              fontWeight: 400,
              lineHeight: '18px',
              letterSpacing: '0em',
              textAlign: 'left',
              color: "#FFFFFF",
              width: '104px',
              height: '18px',
              whiteSpace: 'nowrap',
              marginLeft: '25px',
            }}>
              Complete
            </Typography>
          </Button>
          </div>
          </Item>


          <Item style={{ width: "458px", height: "156px",  padding: "20px", justify: "space-between", border: "1px solid grey"}}>
          <div style={{ marginLeft:"-410px"}}>
          <Checkbox {...label} />
          {/* <img src={rectagle} alt="" /> */}
          </div>
          <Typography variant="body1" style={{
            fontFamily: 'Switzer',
            fontSize: '22px',
            fontWeight: 600,
            lineHeight: '18px',
            letterSpacing: '0em',
            textAlign: 'left',
            color: "grey",
            width: '104px',
            height: '18px',
            whiteSpace: 'nowrap',
            marginLeft: '64px',
            marginTop: "-25px"
          }}>
          Step 5
          </Typography>

          <div style={{marginLeft:"230px", marginTop:"75px"}}>
          <Button variant="contained" style={{ width: "169px", height: "52px", color: "#808080", backgroundColor: "#CCCCCC", cursor: "not-allowed" }} disabled>
            <Typography variant="body1" style={{
              fontFamily: 'Switzer',
              fontSize: '14px',
              fontWeight: 400,
              lineHeight: '18px',
              letterSpacing: '0em',
              textAlign: 'left',
              color: "#FFFFFF",
              width: '104px',
              height: '18px',
              whiteSpace: 'nowrap',
              marginLeft: '25px',
            }}>
              Complete
            </Typography>
          </Button>
          </div>
          </Item>

        </Stack>
      </Box>
    </div>
  );
}

export default Step3;
