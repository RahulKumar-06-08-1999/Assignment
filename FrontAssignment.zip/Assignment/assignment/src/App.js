import React from 'react';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import LandPage from './section/home/home';
import Step1 from './section/home/step1';
import Step2 from './section/home/step2';
import Step3 from './section/home/step3';
import Step4 from './section/home/step4';


import SignUp from './section/home/signup';
import SignIn from './section/home/signin';

function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<LandPage />} />
        <Route path="/step1" element={<Step1 />} />
        <Route path="/step2" element={<Step2 />} />
        <Route path="/step3" element={<Step3 />} />
        <Route path="/step4" element={<Step4 />} />
        <Route path="/signup" element={<SignUp />} />
        <Route path="/signin" element={<SignIn />} />
      </Routes>
    </BrowserRouter>
  );
}

export default App;






// class App extends Component {
//   render() {
//     return (
//       <div className="App">
//           <LandPage />
//           <Step1 />
//       </div>
//     );
//   }
// }

// export default App;